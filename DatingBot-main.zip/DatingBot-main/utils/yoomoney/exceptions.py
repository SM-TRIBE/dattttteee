class UnresolvedRequestMethod(Exception):
    pass


class BadResponse(Exception):
    pass
