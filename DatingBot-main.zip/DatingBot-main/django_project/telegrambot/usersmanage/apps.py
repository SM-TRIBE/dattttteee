from django.apps import (
    AppConfig,
)


class UsersmanageConfig(AppConfig):
    name = "django_project.telegrambot.usersmanage"
